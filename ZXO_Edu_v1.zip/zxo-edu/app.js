const chapters = [
  {title:"مواد و نقش آن‌ها در زندگی", short:"مواد و زندگی"},
  {title:"رفتار اتم‌ها با یکدیگر", short:"رفتار اتم‌ها"},
  {title:"به دنبال محیطی بهتر برای زندگی", short:"محیط زیست"},
  {title:"حرکت چیست؟", short:"حرکت"},
  {title:"نیرو", short:"نیرو"},
  {title:"فشار و آثار آن", short:"فشار"},
  {title:"ماشین‌ها", short:"ماشین‌ها"},
  {title:"زمین‌ساخت ورقه‌ای", short:"زمین‌ساخت"},
  {title:"آثاری از گذشته زمین", short:"گذشته زمین"},
  {title:"نگاهی به فضا", short:"فضا"},
  {title:"گوناگونی جانداران", short:"جانداران"},
  {title:"دنیای گیاهان", short:"گیاهان"},
  {title:"جانوران بی‌مهره", short:"بی‌مهره‌ها"},
  {title:"جانوران مهره‌دار", short:"مهره‌دارها"},
  {title:"با هم زیستن", short:"بوم‌شناسی"}
];

// متن فصل اول یک نمونه آموزشی بازنویسی‌شده است، نه رونویسی از کتاب.
// برای فصل‌های دیگر، نمونه‌های راهنما نمایش داده می‌شود تا محتوای دقیق به‌تدریج تکمیل شود.
const samplePages = [
  {
    label:"بخش اول · آشنایی",
    heading:"مواد اطراف ما",
    body:`<p>هر چیزی که جرم داشته باشد و فضا اشغال کند، ماده است. مواد در زندگی روزمره کاربردهای گوناگونی دارند؛ برای مثال، فلزها در ساخت ابزار، شیشه در پنجره و پلیمرها در بسیاری از وسایل استفاده می‌شوند.</p><p>دانشمندان مواد را بر اساس ویژگی‌هایی مانند سختی، چگالی، رسانایی و واکنش‌پذیری بررسی می‌کنند. شناخت این ویژگی‌ها کمک می‌کند برای هر کاربرد، ماده مناسب‌تری انتخاب کنیم.</p>`,
    key:"انتخاب ماده باید با توجه به ویژگی‌های آن و کاربرد موردنظر انجام شود؛ یک ماده برای همه کارها مناسب نیست.",
    question:"کدام مورد یکی از ویژگی‌های قابل بررسی مواد است؟",
    answers:["رسانایی الکتریکی","نام سازنده وسیله","قیمت فروشگاه به‌تنهایی"],
    correct:0,
    explain:"درست است! رسانایی یکی از ویژگی‌های مواد است و در انتخاب ماده برای سیم‌کشی اهمیت دارد."
  },
  {
    label:"بخش دوم · دسته‌بندی",
    heading:"فلزها و نافلزها؛ یک مقایسه ساده",
    body:`<p>بسیاری از فلزها جلای فلزی دارند و گرما و جریان الکتریکی را به‌خوبی هدایت می‌کنند. به همین دلیل، مس در سیم‌های برق کاربرد زیادی دارد.</p><p>نافلزها ویژگی‌های متنوعی دارند و معمولاً رسانایی الکتریکی کمتری از فلزها دارند؛ البته برای هر قاعده باید به ماده مشخص و شرایط آن توجه کرد. گرافیت، با وجود نافلز بودن، می‌تواند جریان برق را هدایت کند.</p>`,
    key:"برای پاسخ دقیق، ویژگی ماده را بررسی کن؛ از عبارت‌هایی مانند «همه فلزها» یا «همه نافلزها» بدون توجه به استثناها استفاده نکن.",
    question:"چرا مس برای ساخت سیم برق مناسب است؟",
    answers:["چون رسانای خوب جریان الکتریکی است","چون همیشه مایع است","چون جریان برق را کاملاً متوقف می‌کند"],
    correct:0,
    explain:"آفرین! مس رسانایی الکتریکی خوبی دارد و به همین دلیل در سیم‌ها استفاده می‌شود."
  },
  {
    label:"بخش سوم · کاربرد و مرور",
    heading:"انتخاب آگاهانه مواد",
    body:`<p>انتخاب مواد فقط به ویژگی‌های فیزیکی وابسته نیست. هزینه، دوام، امکان بازیافت و اثرات زیست‌محیطی نیز اهمیت دارند.</p><p>برای مثال، هنگام انتخاب بسته‌بندی باید به محافظت از محصول، مقدار مواد مصرفی و امکان استفاده دوباره یا بازیافت توجه کرد. طراحی مناسب می‌تواند به کاهش پسماند کمک کند.</p>`,
    key:"ماده مناسب، ماده‌ای است که نیاز کاربرد را برآورده کند و در کنار آن هزینه و پیامدهای زیست‌محیطی هم در نظر گرفته شود.",
    question:"کدام مورد هنگام انتخاب بسته‌بندی مسئولانه مهم است؟",
    answers:["فقط ظاهر بسته‌بندی","دوام و امکان بازیافت","زیاد بودن مقدار دورریز"],
    correct:1,
    explain:"درست است! دوام و امکان بازیافت می‌توانند به کاهش پسماند و مصرف منابع کمک کنند."
  }
];

const genericPages = [
  {label:"بخش اول · آشنایی", heading:"مفهوم اصلی فصل", body:"<p>این بخش برای تکمیل نسخه اولیه سایت آماده شده است. موضوع فصل را از روی کتاب علوم نهم خود بخوان و مفهوم اصلی را با زبان خودت در این قسمت اضافه کن.</p><p>پیشنهاد: یک تعریف کوتاه، یک مثال از زندگی روزمره و یک شکل یا آزمایش مرتبط بنویس.</p>", key:"خلاصه را با بیان خودت بنویس و آن را با کتاب درسی و توضیح معلم تطبیق بده.", question:"برای کامل کردن این بخش، کدام کار مفیدتر است؟", answers:["نوشتن خلاصه و مثال از روی فهم خودم","کپی کردن متن نامرتبط","حذف سؤال‌ها"], correct:0, explain:"درست است؛ خلاصه‌نویسی با زبان خودت و مثال مرتبط، یادگیری را فعال‌تر می‌کند."},
  {label:"بخش دوم · نکته‌ها", heading:"نکته‌های کلیدی", body:"<p>در این بخش سه نکته مهم فصل را فهرست کن. هر نکته بهتر است کوتاه، دقیق و قابل مرور باشد.</p><ul><li>نکته اول: تعریف یا قانون مهم</li><li>نکته دوم: یک تفاوت یا رابطه</li><li>نکته سوم: یک مثال کاربردی</li></ul>", key:"نکته‌ها را کوتاه بنویس، اما معنی علمی آن‌ها را تغییر نده.", question:"نکته امتحانی خوب چه ویژگی‌ای دارد؟", answers:["کوتاه و دقیق است","عمداً مبهم است","هیچ ارتباطی با درس ندارد"], correct:0, explain:"درست است؛ نکته خوب کوتاه، روشن و مرتبط با هدف یادگیری است."},
  {label:"بخش سوم · خودآزمایی", heading:"مرور و خودآزمایی", body:"<p>پس از مطالعه فصل، دست‌کم دو سؤال تشریحی و سه سؤال چهارگزینه‌ای بساز. پاسخ‌ها را جداگانه بررسی کن و هرجا اشتباه داشتی، به متن درس برگرد.</p>", key:"اشتباه در آزمون تمرینی فرصتی برای پیدا کردن بخش‌هایی است که نیاز به مرور دارند.", question:"اگر جواب یک سؤال را نمی‌دانی، بهترین قدم چیست؟", answers:["حدس بزن و هیچ‌وقت بررسی نکن","به توضیح درس برگرد و دلیل پاسخ را پیدا کن","سؤال را برای همیشه رها کن"], correct:1, explain:"آفرین؛ بررسی دلیل پاسخ کمک می‌کند مفهوم را بهتر یاد بگیری."}
];

const chapterSelect = document.getElementById("chapterSelect");
const chapterList = document.getElementById("chapterList");
const pageTabs = document.getElementById("pageTabs");
let currentChapter = 0;
let currentPage = 0;
let chosen = false;

chapters.forEach((chapter, index) => {
  const option = document.createElement("option");
  option.value = index;
  option.textContent = `فصل ${index + 1} · ${chapter.title}`;
  chapterSelect.appendChild(option);
  const btn = document.createElement("button");
  btn.className = "chapter-item";
  btn.type = "button";
  btn.textContent = `${String(index + 1).padStart(2, "0")}  ${chapter.title}`;
  btn.addEventListener("click", () => loadChapter(index));
  chapterList.appendChild(btn);
});

function pagesForChapter(index) {
  return index === 0 ? samplePages : genericPages;
}

function loadChapter(index) {
  currentChapter = index;
  currentPage = 0;
  chapterSelect.value = index;
  [...chapterList.children].forEach((el, i) => el.classList.toggle("active", i === index));
  document.getElementById("chapterNumber").textContent = `فصل ${index + 1}`;
  document.getElementById("chapterTitle").textContent = chapters[index].title;
  renderPage();
}

function renderPage() {
  const pages = pagesForChapter(currentChapter);
  const page = pages[currentPage];
  pageTabs.innerHTML = "";
  pages.forEach((p, i) => {
    const btn = document.createElement("button");
    btn.className = `page-tab${i === currentPage ? " active" : ""}`;
    btn.type = "button";
    btn.setAttribute("role", "tab");
    btn.setAttribute("aria-selected", i === currentPage ? "true" : "false");
    btn.textContent = `بخش ${i + 1}`;
    btn.addEventListener("click", () => { currentPage = i; renderPage(); });
    pageTabs.appendChild(btn);
  });
  document.getElementById("progressText").textContent = `بخش ${currentPage + 1} از ${pages.length}`;
  document.getElementById("progressBar").style.width = `${((currentPage + 1) / pages.length) * 100}%`;
  document.getElementById("pageLabel").textContent = page.label;
  document.getElementById("pageHeading").textContent = page.heading;
  document.getElementById("pageBody").innerHTML = page.body;
  document.getElementById("keyPoint").textContent = page.key;
  document.getElementById("questionText").textContent = page.question;
  document.getElementById("feedback").textContent = "";
  document.getElementById("feedback").className = "feedback";
  chosen = false;
  const answers = document.getElementById("answers");
  answers.innerHTML = "";
  page.answers.forEach((answer, i) => {
    const btn = document.createElement("button");
    btn.className = "answer-btn";
    btn.type = "button";
    btn.textContent = `${["الف", "ب", "ج", "د"][i]}) ${answer}`;
    btn.addEventListener("click", () => {
      if (chosen) return;
      chosen = true;
      const feedback = document.getElementById("feedback");
      if (i === page.correct) {
        btn.classList.add("correct");
        feedback.textContent = page.explain;
        feedback.classList.add("good");
      } else {
        btn.classList.add("wrong");
        answers.children[page.correct].classList.add("correct");
        feedback.textContent = `این گزینه درست نیست. ${page.explain}`;
        feedback.classList.add("bad");
      }
    });
    answers.appendChild(btn);
  });
  document.getElementById("prevBtn").disabled = currentPage === 0;
  document.getElementById("prevBtn").style.opacity = currentPage === 0 ? ".45" : "1";
  document.getElementById("nextBtn").textContent = currentPage === pages.length - 1 ? "بازگشت به بخش اول ↻" : "بخش بعدی ←";
}

chapterSelect.addEventListener("change", (event) => loadChapter(Number(event.target.value)));
document.getElementById("prevBtn").addEventListener("click", () => {
  if (currentPage > 0) { currentPage--; renderPage(); }
});
document.getElementById("nextBtn").addEventListener("click", () => {
  const pages = pagesForChapter(currentChapter);
  currentPage = currentPage === pages.length - 1 ? 0 : currentPage + 1;
  renderPage();
});
document.getElementById("printBtn").addEventListener("click", () => window.print());
loadChapter(0);
